package com.example.dao;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.entity.Student;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Repository
@Transactional
public class StudentDAO {

    @PersistenceContext
    private EntityManager entityManager;

    // 1. Add Student
    public void addStudent(Student student) {
        entityManager.persist(student);
    }

    // 2. Display All Students
    public List<Student> getAllStudents() {
        return entityManager
                .createQuery("SELECT s FROM Student s", Student.class)
                .getResultList();
    }

    // 3. Search Student by ID
    public Student getStudentById(String regno) {
        return entityManager.find(Student.class, regno);
    }

    // 4. Update Student
    public void updateStudent(Student student) {
        entityManager.merge(student);
    }

    // 5. Delete Student
    public void deleteStudent(String regno) {
        Student student = entityManager.find(Student.class, regno);

        if (student != null) {
            entityManager.remove(student);
        }
    }
}