package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.dao.StudentDAO;
import com.example.entity.Student;

@Controller
public class StudentController {

    @Autowired
    private StudentDAO studentDAO;

    // Home page
    @GetMapping("/")
    public String home() {
        return "index";
    }

    // Add Student
    @PostMapping("/add")
    public String addStudent(
            @RequestParam("regno") String regno,
            @RequestParam("name") String name,
            @RequestParam("cgpa") double cgpa) {

        Student student = new Student(regno, name, cgpa);

        studentDAO.addStudent(student);

        return "redirect:/students";
    }

    // Display All Students
    @GetMapping("/students")
    public String getAllStudents(Model model) {

        List<Student> students = studentDAO.getAllStudents();

        model.addAttribute("students", students);

        return "students";
    }

    // Search Student
    @GetMapping("/search")
    public String searchStudent(
            @RequestParam("regno") String regno,
            Model model) {

        Student student = studentDAO.getStudentById(regno);

        model.addAttribute("student", student);

        return "searchResult";
    }

    // Show Update Form
    @GetMapping("/edit")
    public String showUpdateForm(
            @RequestParam("regno") String regno,
            Model model) {

        Student student = studentDAO.getStudentById(regno);

        model.addAttribute("student", student);

        return "updateStudent";
    }

    // Update Student
    @PostMapping("/update")
    public String updateStudent(
            @RequestParam("regno") String regno,
            @RequestParam("name") String name,
            @RequestParam("cgpa") double cgpa) {

        Student student = new Student(regno, name, cgpa);

        studentDAO.updateStudent(student);

        return "redirect:/students";
    }

    // Delete Student
    @GetMapping("/delete")
    public String deleteStudent(
            @RequestParam("regno") String regno) {

        studentDAO.deleteStudent(regno);

        return "redirect:/students";
    }
}