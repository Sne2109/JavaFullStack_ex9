<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>

<html>

<head>

    <title>All Students</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f8;
            padding: 40px;
            text-align: center;
        }

        table {
            width: 80%;
            margin: auto;
            border-collapse: collapse;
            background: white;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 12px;
        }

        th {
            background-color: #eeeeee;
        }

        a {
            text-decoration: none;
            margin: 5px;
        }

    </style>

</head>

<body>

    <h1>All Students</h1>

    <table>

        <tr>
            <th>Registration No</th>
            <th>Name</th>
            <th>CGPA</th>
            <th>Action</th>
        </tr>

        <c:forEach var="student" items="${students}">

            <tr>

                <td>${student.regno}</td>

                <td>${student.name}</td>

                <td>${student.cgpa}</td>

                <td>

                    <a href="${pageContext.request.contextPath}/edit?regno=${student.regno}">
                        Edit
                    </a>

                    |

                    <a href="${pageContext.request.contextPath}/delete?regno=${student.regno}">
                        Delete
                    </a>

                </td>

            </tr>

        </c:forEach>

    </table>

    <br>

    <a href="${pageContext.request.contextPath}/">
        Back to Home
    </a>

</body>

</html>