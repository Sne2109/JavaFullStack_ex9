<%@ page contentType="text/html;charset=UTF-8" %>

<!DOCTYPE html>
<html>

<head>
    <title>Update Student</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f8;
            text-align: center;
            padding: 40px;
        }

        .container {
            width: 450px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        input {
            width: 90%;
            padding: 10px;
            margin: 10px;
        }

        button {
            padding: 10px 25px;
            margin: 10px;
            cursor: pointer;
        }

        a {
            text-decoration: none;
        }
    </style>

</head>

<body>

<div class="container">

    <h1>Update Student</h1>

    <form action="${pageContext.request.contextPath}/update" method="post">

        <input type="text"
               name="regno"
               value="${student.regno}"
               readonly>

        <br>

        <input type="text"
               name="name"
               value="${student.name}"
               placeholder="Student Name"
               required>

        <br>

        <input type="number"
               name="cgpa"
               value="${student.cgpa}"
               step="0.01"
               min="0"
               max="10"
               required>

        <br>

        <button type="submit">
            Update Student
        </button>

    </form>

    <br>

    <a href="${pageContext.request.contextPath}/students">
        Back to Students
    </a>

</div>

</body>

</html>