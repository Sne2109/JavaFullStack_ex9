<%@ page contentType="text/html;charset=UTF-8" %>

<!DOCTYPE html>
<html>
<head>
    <title>Student Management System</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f8;
            text-align: center;
            padding: 40px;
        }

        .container {
            width: 500px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        input {
            width: 90%;
            padding: 10px;
            margin: 8px;
        }

        button {
            padding: 10px 20px;
            margin: 8px;
            cursor: pointer;
        }

        a {
            display: inline-block;
            margin: 10px;
            text-decoration: none;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>Student Management System</h1>

    <h2>Add Student</h2>

    <form action="${pageContext.request.contextPath}/add" method="post">

        <input type="text"
               name="regno"
               placeholder="Registration Number"
               required>

        <br>

        <input type="text"
               name="name"
               placeholder="Student Name"
               required>

        <br>

        <input type="number"
               name="cgpa"
               placeholder="CGPA"
               step="0.01"
               min="0"
               max="10"
               required>

        <br>

        <button type="submit">Add Student</button>

    </form>

    <hr>

    <h2>Other Operations</h2>

    <a href="${pageContext.request.contextPath}/students">
        View All Students
    </a>

    <br>

    <form action="${pageContext.request.contextPath}/search" method="get">

        <input type="text"
               name="regno"
               placeholder="Enter Reg No"
               required>

        <button type="submit">Search Student</button>

    </form>

</div>

</body>
</html>