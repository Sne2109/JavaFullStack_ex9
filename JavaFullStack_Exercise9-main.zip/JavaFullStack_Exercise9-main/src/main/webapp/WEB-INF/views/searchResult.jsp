<%@ page contentType="text/html;charset=UTF-8" %>

<!DOCTYPE html>
<html>

<head>
    <title>Search Result</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f8;
            text-align: center;
            padding: 50px;
        }

        .result {
            width: 400px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        a {
            text-decoration: none;
            margin: 10px;
            display: inline-block;
        }
    </style>
</head>

<body>

<div class="result">

    <h1>Search Result</h1>

    <%
        if (request.getAttribute("student") != null) {
    %>

        <p>
            <strong>Registration No:</strong>
            ${student.regno}
        </p>

        <p>
            <strong>Name:</strong>
            ${student.name}
        </p>

        <p>
            <strong>CGPA:</strong>
            ${student.cgpa}
        </p>

    <%
        } else {
    %>

        <h3>Student Not Found</h3>

    <%
        }
    %>

    <br>

    <a href="${pageContext.request.contextPath}/">
        Back to Home
    </a>

    <a href="${pageContext.request.contextPath}/students">
        View All Students
    </a>

</div>

</body>

</html>